#include <NodeManager.hpp>
#include <Node.hpp>

std::vector<MyNode>& NodeManager::getNodes(){
	return nodes;
}

void NodeManager::addNode(MyNode n){
	nodes.push_back(n);
}

MyNode& NodeManager::indexToRef(unsigned int currentNodeIndex){
	return nodes[currentNodeIndex];
}