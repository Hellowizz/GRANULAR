#include <iostream>
#include <string>
#include <Kendy.hpp>

using namespace std; 

Kendy::Kendy(){
	affection = 100;
}

void Kendy::addAffection(int a){
	affection += a;
}

int Kendy::getAffection(){
	return affection;
}

bool Kendy::testAffection(int a){
	if(affection > a){
		return true;
	}else{
		return false;
	}
}

void Kendy::putAffection(int a){
	affection = a;
}

Kendy::~Kendy(){}