#include <gameManager.hpp>

GameManager::GameManager(Dog d, Kendy k){
	hungarianMudi = d;
	kend = k;
}

Dog& GameManager::getDog(){
	return hungarianMudi;
}

Kendy& GameManager::getKendy(){
	return kend;
}