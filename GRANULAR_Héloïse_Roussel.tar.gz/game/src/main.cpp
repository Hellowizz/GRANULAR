#include <iostream>
#include <string> 
#include <vector>

#include <FileManager.hpp>
#include <Interface.hpp>
#include <Dog.hpp>
#include <Kendy.hpp>
#include <gameManager.hpp>

using namespace std;

int main(){

	FileManager manager;

    NodeManager managerNode = manager.readFile("Story.txt");

    Dog hungarianMudi;
    Kendy ken;
    GameManager gm(hungarianMudi, ken);

    Interface inter(managerNode);
    inter.game(gm);

	return 0;
}