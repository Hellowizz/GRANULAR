#include <iostream>
#include <string>
#include <Dog.hpp>

using namespace std; 

Dog::Dog(){
	name = "";
	affection = 100;
}

void Dog::putName(){
	string s;

	cout << "Please, enter a name for the dog." << endl;

	cin >> s;
	while(!cin.good()){
		cerr << "Please, answer something." << endl;
	}
	name = s;
}

string Dog::getName(){
	return name;
}

void Dog::putName(string s){
	name = s;
}

void Dog::addAffection(int a){
	affection += a;
}

int Dog::getAffection(){
	return affection;
}

void Dog::putAffection(int a){
	affection = a;
}


bool Dog::testAffection(int a){
	if(affection < a){
		return false;
	}else{
		return true;
	}
}

Dog::~Dog(){}