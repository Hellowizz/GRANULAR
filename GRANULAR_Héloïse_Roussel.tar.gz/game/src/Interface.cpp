#include <iostream>
#include <unistd.h>
#include <cstdlib>
#include <string>
#include <fstream>

#include <Interface.hpp>
#include <NodeManager.hpp>
#include <Answer.hpp>
#include <Dog.hpp>
#include <Kendy.hpp>

using namespace std;


Interface::Interface (int currentNodeIndex, bool EOG) : currentNodeIndex(currentNodeIndex), EOG(EOG) {}

Interface::Interface(NodeManager managerNode){
	currentNodeIndex = 1;
	EOG = false;
	nmg = managerNode;
}

void Interface::game(GameManager &gm){

	while(!EOG){
		MyNode &node = nmg.indexToRef(currentNodeIndex);

		passedNodes.push_back(currentNodeIndex);
		
		cout << "\033c" << endl;

		progressivePrint(node.getConvertedText(gm.getDog(), gm.getKendy(), EOG));
		
		if(EOG) break;

		for(auto answer: node.getAnswers()){
			bool b = true;
			for(unsigned int i=0; i<passedNodes.size(); i++){
				if(answer.getIndexFollowingNode() == passedNodes[i]){
					b = false;
				}
			}
			if(b)
				cout << answer.getText();
		}
		
		for(;;) {
			string s;

			cout << "\n-----" << endl;
			cin >> s;
			if(!cin.good()){
				cerr << "Please, answer something." << endl;
				continue;
			}
			else if(!(s[0] >= 'a' && s[0] < 'a'+(int) node.getAnswers().size()) && s != "save" && s != "load") {
				cerr << "Please, answer a valid thing" << endl;
				continue;
			}else if(s == "save"){
				save(gm);
			}else if(s == "load"){
				load(gm);
			}else{
				unsigned int carac = s[0] - 'a';
				currentNodeIndex = node.getAnswers()[carac].getIndexFollowingNode();
			}

			break;
		}
	}

	cout << "This is the end of the way, you can try again to get a better end if you want." << endl;
}

void Interface::changeEOG(){

	if(!EOG)
		EOG = true;
	else
		EOG = false;
}

void Interface::progressivePrint(string s){
	int attend;
	for(int i=0; i<(int)s.size(); i++){
		if(s[i] == '?' || s[i] == '!' || s[i] == '.' || s[i] == '\n'){
			attend = 1000000;
		}else{
			attend = 45500 + rand() % 15000 + 1;
		}
		cout << s[i];
		cout.flush();
		usleep(attend);
	}
}

void Interface::progressivePrintAnswers(MyNode n){
	const std::vector<Answer> &answers = n.getAnswers();

	for(auto const& MyAnswer: answers){
		progressivePrint(MyAnswer.getText());
	}
}

void Interface::save(GameManager &gm){
	ofstream myfile;
  	myfile.open ("save.txt");
  	myfile << currentNodeIndex << endl;
  	myfile << gm.getDog().getName() << endl;
  	myfile << gm.getDog().getAffection() << endl;
  	myfile << gm.getKendy().getAffection() << endl;

  	for(int number: passedNodes){
  		myfile << number << ";";
	}

  	myfile.close();

  	cout << "game saved" << endl;
  	exit(4);
}

void Interface::load(GameManager &gm){

	string allFile = "", line;

	std::ifstream file("save.txt", std::ios::binary | std::ios::ate);
    if(!file.is_open()){
        cout << "The file of save doesn't exist." << endl;
        exit(5);
    }

    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);

    std::vector<char> buffer(size);

    if (!file.read(buffer.data(), size)){
        cout << "ERROR, file can not be read" << endl;
        exit(6);
    }

    int nbLine = 1;
    for(unsigned int i=0; i<buffer.size();){

    		//LINE 1
    	string newNumberNodeString;
		while(buffer[i] != '\n'){
			newNumberNodeString += buffer[i];
			i++;
		}
		currentNodeIndex = atoi(newNumberNodeString.c_str());
		nbLine ++;
		i++;

			//LINE 2

		string newNameDog;
		while(buffer[i] != '\n'){
			newNameDog += buffer[i];
			i++;
		}
		gm.getDog().putName(newNameDog);
		nbLine ++;
		i++;

			//LINE 3

		string newDogAffectionString;
		while(buffer[i] != '\n'){
			newDogAffectionString += buffer[i];
			i++;
		}
		gm.getDog().putAffection(atoi(newDogAffectionString.c_str()));
		nbLine ++;
		i++;

			//LINE 4

		string newKendyAffectionString;
		while(buffer[i] != '\n'){
			newKendyAffectionString += buffer[i];
			i++;
		}
		gm.getKendy().putAffection(atoi(newKendyAffectionString.c_str()));
		nbLine ++;
		i++;
    	
			//LINE 5

		while(buffer[i] != '\0'){
			string newPassedNodeString;
			while(buffer[i] != ';'){
				newPassedNodeString += buffer[i];
				i++;
			}
			passedNodes.push_back(atoi(newPassedNodeString.c_str()));
			i++;
		}
		nbLine ++;
		i++;
    }
}