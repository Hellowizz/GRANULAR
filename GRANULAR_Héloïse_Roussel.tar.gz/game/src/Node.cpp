#include <fstream>
#include <iostream>
#include <Node.hpp>
#include <string>
#include <unistd.h>

using namespace std;

int MyNode::total_number = 0;

MyNode::MyNode() {
	text = "";
	total_number++;
	number = total_number;
}

string MyNode::getText(){
	return text;
}
 
void MyNode::addText(char c){
		text += c;
}

void MyNode::addAnswer(Answer a){
	answers.push_back(a);
}

string MyNode::getConvertedText(Dog &d, Kendy &k, bool &EOG){

	string word = "";
	string number = "";
	string newText = "";

	int numberInt;

	for(size_t i=0 ; i<text.length() ; ) {
		if(text[i] != '#'){
			newText += text[i];
			i++;
		}else{
			for(size_t j=i ; text[j] != ' ' && text[j] != '\n' ; j++)
				word += text[j];

			if(word == "#Dog"){
				newText += d.getName();
			}else if(word == "#PutDogName"){
				d.putName();
			}else if(word == "#EndOfTheRoad"){
				EOG = true;
			}else if(isdigit(word[2])){
				for(size_t h=2 ; isdigit(word[h]) ; h++)
					number += word[h];
				numberInt = atoi(number.c_str());

				if(word[1] == '-'){
					if(word[word.length()-1] == 'D')
						d.addAffection( - numberInt );
					if(word[word.length()-1] == 'K')
						k.addAffection( - numberInt );
				}else if(word[1] == '+'){
					if(word[word.length()-1] == 'D')
						d.addAffection( numberInt );
					if(word[word.length()-1] == 'K')
						k.addAffection(numberInt);
				}
			}else if(word[1] == 'i'){
				for(size_t h=3 ; isdigit(word[h]) ; h++)
					number += word[h];
				numberInt = atoi(number.c_str());
				bool b = false;

				if(word[word.length()-1] == 'K')
					b = k.testAffection(numberInt);
				else if(word[word.length()-1] == 'D')
					b = d.testAffection(numberInt);

				if(!b){
					while(text[i + word.length()] != '#' || text[i+1] != 'e'){
						i++;
					}
					i-= word.length();
				}
			}


			i+= word.length();
			word = "";
		}
		
	}

	return newText;
}

std::vector<Answer>& MyNode::getAnswers() {
	return answers;
}

Answer& MyNode::indexToRef(unsigned int currentNodeIndex){
	return answers[currentNodeIndex];
}

void MyNode::createAnswer(string line){
	Answer a;
	a.addText(line);
	answers.push_back(a);
}


MyNode::~MyNode(){total_number--;}