#include <fstream>
#include <iostream>
#include <string> 
#include <vector>
#include <string>
#include <stdlib.h> 
#include <unistd.h>
#include <cstdlib>
#include <cctype>

#include <NodeManager.hpp>
#include <FileManager.hpp>
#include <Node.hpp>
#include <Answer.hpp>
#include <Interface.hpp>

using namespace std;

FileManager::FileManager(){}

NodeManager FileManager::createGraph(std::vector<char> buffer){
	NodeManager managerNode;

	bool b = false; 
	MyNode node;
	managerNode.addNode(node);
	string line;
	int nbNode = 0, nbAnswer = 0;

	Interface inter;

	for(unsigned int i=0; i<buffer.size();){
		if(buffer[i] == '\n' && buffer[i+1] == '\n'){
			i++;
		}
		if(b){
			if(buffer[i] != '='){
				managerNode.getNodes()[nbNode].addText(buffer[i]);
				i++;
			}else{
				b = false;
				i++;			
			}
		}else{
			if(buffer[i] != '='){
				if(!isdigit(buffer[i])){
					line += buffer[i];
					i++;
				}else{
					int idFollowingNode;
					string idFollowingNodeString = "";
					idFollowingNodeString += buffer[i];

					while(isdigit(buffer[i+1])){
						idFollowingNodeString += buffer[i+1];
						i++;
					}

					idFollowingNode = atoi(idFollowingNodeString.c_str());

					managerNode.getNodes()[nbNode].createAnswer(line);
					managerNode.getNodes()[nbNode].getAnswers()[nbAnswer].putIndexFollowingNode(idFollowingNode);

					nbAnswer ++;
					line = "";
					i += 2;				
				}
			}else{
				MyNode node;
				managerNode.addNode(node);
				nbNode ++;
				nbAnswer = 0;
				b = true;
				i++;
			}
		}
	}

	return managerNode;
}

NodeManager FileManager::readFile(string nameFile){
	string allFile = "", line;

	std::ifstream file(nameFile, std::ios::binary | std::ios::ate);
    if(!file.is_open()){
        cout << "The file is not open." << endl;
        exit(1);
    }

    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);

    std::vector<char> buffer(size);

    if (!file.read(buffer.data(), size)){
        cout << "ERROR, file can not be read" << endl;
        exit(2);
    }

    return FileManager::createGraph(buffer);
}