#include <Answer.hpp>

using namespace std;

Answer::Answer(){
	text = "";
}

void Answer::addText (string line){
	text += line;
}

string Answer::getText() const{
	return text;
}

int Answer::getIndexFollowingNode(){
	return indexFollowingNode;
}

void Answer::putIndexFollowingNode(int id){
	indexFollowingNode = id;
}