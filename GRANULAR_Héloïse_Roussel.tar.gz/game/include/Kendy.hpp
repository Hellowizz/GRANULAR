#pragma once
#include <string>

class Kendy{
private:
	int affection;

public:
	Kendy();

	void addAffection(int a);
	int getAffection();

	bool testAffection(int a);
	void putAffection(int a);

	~Kendy();
};