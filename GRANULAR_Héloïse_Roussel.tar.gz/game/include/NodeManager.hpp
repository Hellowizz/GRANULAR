#pragma once
#include <Node.hpp>
#include <Dog.hpp>
#include <vector>

class NodeManager{
private :
	std::vector<MyNode> nodes;
	Dog hungarianMudi;
public :
	
	std::vector<MyNode>& getNodes();
	void addNode(MyNode n);
	MyNode& indexToRef(unsigned int currentNodeIndex);

};