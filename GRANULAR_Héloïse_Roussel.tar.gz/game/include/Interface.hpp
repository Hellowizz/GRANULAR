#pragma once
#include <string>
#include <Node.hpp>
#include <NodeManager.hpp>
#include <gameManager.hpp>

class Interface{
private:
	int currentNodeIndex;
	bool EOG;
	NodeManager nmg;

public:
	std::vector<int> passedNodes;

	Interface(int currentNode=1, bool EOG = false);
	Interface(NodeManager managerNode);

	void game(GameManager &gm);
	void changeEOG();
	void progressivePrint(std::string s);
	void progressivePrintAnswers(MyNode n);
	void save(GameManager &gm);
	void load(GameManager &gm);
}; 