#pragma once
#include <string>

class Dog{
private:
	std::string name;
	int affection;

public:
	Dog();

	void putName();
	std::string getName();
	void putName(std::string s);
	void addAffection(int a);
	int getAffection();
	void putAffection(int a);

	bool testAffection(int a);

	~Dog();
};