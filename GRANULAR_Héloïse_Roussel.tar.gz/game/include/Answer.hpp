#pragma once
#include <string>

class Answer{
private:
	std::string text;
	int indexFollowingNode;

public:
	Answer();
	void addText (std::string line);
	std::string getText() const;
	int getIndexFollowingNode();
	void putIndexFollowingNode(int id);
};