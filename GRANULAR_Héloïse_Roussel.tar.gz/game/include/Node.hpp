#pragma once
#include <string>
#include <vector>

#include <Answer.hpp>
#include <Dog.hpp>
#include <Kendy.hpp>

class MyNode{
private:
    int number;
    std::string text;
    std::vector<Answer> answers;
    
public:
	static int total_number;
	MyNode();

	std::string getText();

	void addText(char c);
	void addAnswer(Answer a);
	std::string getConvertedText(Dog &d, Kendy &k, bool &EOG);

	std::vector<Answer>& getAnswers();
	Answer& indexToRef(unsigned int currentNodeIndex);
	void createAnswer(std::string line);
	~MyNode();
};