#pragma once
#include <string>

#include <Dog.hpp>
#include <Kendy.hpp>

class GameManager{
private:
    Dog hungarianMudi;
    Kendy kend;
    
public:
	GameManager(Dog d, Kendy k);

	Dog& getDog();

	Kendy& getKendy();
};