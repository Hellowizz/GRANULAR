#pragma once

#include <string>

#include <NodeManager.hpp>

class FileManager{
private:
	std::string allFile;
public:
	FileManager();
	
	NodeManager createGraph(std::vector<char> buffer);
	NodeManager readFile(std::string nameFile);
};